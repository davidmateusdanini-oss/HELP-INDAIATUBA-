package com.help.indaiatuba.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.help.indaiatuba.databinding.ItemProviderBinding

class ProviderAdapter(private val items: List<Provider>) : RecyclerView.Adapter<ProviderAdapter.VH>() {
    inner class VH(val binding: ItemProviderBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(ItemProviderBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.name.text = item.name
        holder.binding.slots.text = item.slots
        holder.binding.price.text = item.price
    }

    override fun getItemCount() = items.size
}
