package com.help.indaiatuba.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.help.indaiatuba.databinding.ActivityResultsBinding

class ResultsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val tipo = intent.getStringExtra("tipo") ?: "Serviço"
        val bairro = intent.getStringExtra("bairro") ?: ""

        binding.title.text = "Encontramos opções para: $tipo"
        binding.subtitle.text = "Próximo a $bairro"

        val items = listOf(
            Provider("Encanador Silva", "Hoje 14:00, 16:30", "A partir de R$ 120"),
            Provider("Hidráulica Rápida", "Hoje 18:00 • Amanhã 09:00", "A partir de R$ 100"),
            Provider("SOS Canos", "Amanhã 10:30, 13:00", "A partir de R$ 110")
        )
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = ProviderAdapter(items)
    }
}

data class Provider(val name: String, val slots: String, val price: String)
