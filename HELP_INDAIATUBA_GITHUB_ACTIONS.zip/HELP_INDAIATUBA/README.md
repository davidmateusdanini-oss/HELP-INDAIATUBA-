# HELP INDAIATUBA

Concierge de serviços para clientes e fornecedores — interface simples e acolhedora.

## Telas
- **Formulário**: tipo de serviço, descrição, bairro, horário.
- **Buscando**: animação de **passos**; ao encontrar, mostra **mão apontando** + **lâmpada** e botão *Ver opções*.
- **Resultados**: lista de fornecedores (exemplo) com valores e horários.

## Backend / IA
Substitua o `postDelayed` na `SearchingActivity` por uma chamada à sua API (ex.: Firebase, Cloud Run).
Alimente a lista de resultados com os dados vindos do servidor.

## Publicação
1. Abrir no Android Studio (Giraffe+), sincronizar Gradle.
2. **Build > Generate Signed App Bundle...** → `.aab` (release).
3. Enviar no **Google Play Console**; preencher ficha da loja e política de privacidade.
